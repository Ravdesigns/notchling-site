# Notchling
A little creature that lives in your MacBook notch. Drag a file near it and it
opens its mouth and holds it for you; drag the file back out whenever you need it.
Right-click the notch for everything else. macOS 13+, nothing else needed.

The creature is free and stays free. Notchling Pro ($12 once) adds chewing files,
reading text out of screenshots, timers, music controls, the weather scenes, and
the Downloads and calendar watchers. Right-click → Unlock Pro.

Install: drag Notchling.app to /Applications, right-click → Open the first time.
