# Notchling
A little creature that lives in your MacBook notch. Drag a file near it and it
opens its mouth and holds it for you; drag the file back out whenever you need it.
Right-click the notch to switch to the weather. macOS 13+, nothing else needed.

Install: drag Notchling.app to /Applications, right-click → Open the first time.
